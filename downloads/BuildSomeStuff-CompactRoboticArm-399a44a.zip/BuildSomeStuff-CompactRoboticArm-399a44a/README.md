# CompactRoboticArm

Here lies all CAD, STL, and Code files for the Robotic Arm shown in this video: https://youtu.be/5toNqaGsGYs

Here are the CAD files that can be edited in Fusion 360: https://drive.google.com/drive/folders/1x4P8AquQILwCp8e5CiRJLfVJiJn2U4cF?usp=sharing

PLEASE NOTE: These designs and code are FAR from perfect. There are still many improvements that can be made to both. I am just sharing my work with the community as it is, and it may not work for you exactly as it does in the video. This arm will require a lot of soldering, especially for the controller. The arm also requires other small parts that were not mentioned in the video like a few small gears for the last rotational segment of the arm and some extra wires. At the time of designing and recording, I had not planned on making this arm open source. That is why the arm may be difficult to replicate and why it was not explained in great detail. 

All files here are FREE, but I would highly appreciate your support through Patreon here to continue making these robotics projects: https://www.patreon.com/BuildSomeStuff

Thanks, and best of luck!
